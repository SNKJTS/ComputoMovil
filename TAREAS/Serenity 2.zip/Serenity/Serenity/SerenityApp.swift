//
//  SerenityApp.swift
//  Serenity
//
//  Created by Alumno on 03/04/25.
//

import SwiftUI

@main
struct SerenityApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                Serenity()
            }
        }
    }
}
