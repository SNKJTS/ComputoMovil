import SwiftUI

struct Serenity: View {
    @State private var isMenuOpen = false
    
    var body: some View {
        NavigationStack {
            ZStack {
                // Contenido principal
                VStack {
                    // Encabezado
                    HStack {
                        Button(action: { isMenuOpen.toggle() }) {
                            Image(systemName: "line.horizontal.3")
                                .font(.system(size: 40, weight: .bold)) // Tamaño y peso personalizados
                                .symbolVariant(.fill) // Variante "fill" para líneas más gruesas
                                .padding(.trailing, 40)
                        }
                        
                        Text("Serenity")
                            .font(.largeTitle)
                            .bold()
                        
                        Spacer()
                            .frame(width: 44) // Balancea el espacio
                    }
                    .padding(.horizontal)
                    .padding(.top, 10)
                    
                    // Contenido
                    Text("_-_ Siempre es buena idea hacer algo relajante _-_")
                        .multilineTextAlignment(.center)
                        .padding()
                    
                    Text("- Paulo Coelho")
                        .italic()
                        .padding(.bottom, 20)
                    
                    
                    // Lista de características
                    FeatureListView()
                    
                    Spacer()
                    
                    // Barra inferior
                    BottomBarView()
                }
                .blur(radius: isMenuOpen ? 3 : 0)
                
                // Menú lateral
                SideMenuView(isMenuOpen: $isMenuOpen)
                    .offset(x: isMenuOpen ? 0 : -500)
                
            }
        }
    }
}

// Componentes reutilizables:

struct PrimaryButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.title2)
            .padding()
            .frame(maxWidth: .infinity)
            .background(Color.blue)
            .foregroundColor(.white)
            .clipShape(Capsule())
            .shadow(radius: 5)
            .padding(.horizontal, 50)
    }
}

struct FeatureListView: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 90) {
            FeatureView(text: "Alcanza tus metas", subtitle: "Cuida tu salud mental")
            FeatureView(text: "Mejora tu día a día", subtitle: "Libérate del estrés y la ansiedad")
            FeatureView(text: "Duerme como siempre quisiste", subtitle: "Descansa profundamente")
        }
        .padding()
    }
}

struct FeatureView: View {
    let text: String
    let subtitle: String
    
    var body: some View {
        HStack {
            Circle()
                .fill(Color.purple.opacity(0.5))
                .frame(width: 30, height: 30)
            
            VStack(alignment: .leading) {
                Text(text)
                    .font(.headline)
                Text(subtitle)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        }
    }
}

struct BottomBarView: View {
    var body: some View {
        HStack {
            Image(systemName: "house")
            Spacer()
            Image(systemName: "smiley")
            Spacer()
            Image(systemName: "ellipsis")
            Spacer()
            Image(systemName: "circle.fill")
        }
        .padding()
        .background(Color.gray.opacity(0.2))
    }
}

struct SideMenuView: View {
    @Binding var isMenuOpen: Bool
    
    var body: some View {
        ZStack {
            // Fondo semitransparente
            Color.black.opacity(0.3)
                .onTapGesture { isMenuOpen = false }
            
            // Menú
            HStack {
                VStack(alignment: .leading, spacing: 60) {
                    MenuButton(icon: "leaf", text: "Meditaciones", destination: MeditacionesView(), isMenuOpen: $isMenuOpen)
                    MenuButton(icon: "chart.bar", text: "Progreso", destination: ProgresoView(), isMenuOpen: $isMenuOpen)
                    MenuButton(icon: "person", text: "Perfil", destination: PerfilView(), isMenuOpen: $isMenuOpen)
                    MenuButton(icon: "gear", text: "Configuración", destination: ConfiguracionView(), isMenuOpen: $isMenuOpen)
                    
                    Spacer()
                }
                .padding(30)
                .frame(width: 250)
                .background(Color.white)
                .padding(.top, 50)
                Spacer()
            }
        }
        .edgesIgnoringSafeArea(.all)
    }
}

struct MenuButton<Destination: View>: View {
    let icon: String
    let text: String
    let destination: Destination
    @Binding var isMenuOpen: Bool
    
    var body: some View {
        NavigationLink(destination: destination) {
            HStack(spacing: 15) {
                Image(systemName: icon)
                Text(text)
                Spacer()
            }
            .foregroundColor(.black)
            .padding(.vertical, 10)
        }
        .simultaneousGesture(TapGesture().onEnded {
            isMenuOpen = false
        })
    }
}


struct MeditacionesView: View {
    let sesiones = [
        ("Respiración guiada", "10 min", "leaf.fill"),
        ("Alivio de ansiedad", "15 min", "cloud.sun.fill"),
        ("Sueño profundo", "20 min", "moon.zzz.fill")
    ]
    
    var body: some View {
        List(sesiones, id: \.0) { nombre, duracion, icono in
            HStack {
                Image(systemName: icono)
                    .foregroundColor(.blue)
                    .frame(width: 30)
                VStack(alignment: .leading) {
                    Text(nombre)
                        .font(.headline)
                    Text(duracion)
                        .font(.caption)
                        .foregroundColor(.gray)
                }
                Spacer()
                Image(systemName: "play.circle.fill")
                    .foregroundColor(.blue)
            }
            .padding(.vertical, 8)
        }
        .navigationTitle("Meditaciones")
        .toolbar {
            Button(action: {}) {
                Image(systemName: "plus")
            }
        }
    }
}

struct ProgresoView: View {
    let datos = [5, 8, 12, 9, 15, 11]
    let dias = ["L", "M", "M", "J", "V", "S"]
    
    var body: some View {
        VStack(spacing: 20) {
            Text("Tus últimos 7 días")
                .font(.title2)
                .padding(.top)
            
            HStack(alignment: .bottom, spacing: 15) {
                ForEach(0..<datos.count, id: \.self) { index in
                    VStack {
                        Text("\(datos[index])")
                            .font(.caption)
                        Rectangle()
                            .fill(Color.blue)
                            .frame(width: 20, height: CGFloat(datos[index]) * 5)
                        Text(dias[index])
                            .font(.caption)
                    }
                }
            }
            .frame(height: 200)
            .padding()
            
            Spacer()
        }
        .navigationTitle("Progreso")
    }
}

struct PerfilView: View {
    var body: some View {
        VStack(spacing: 20) {
            Image(systemName: "person.crop.circle.fill")
                .resizable()
                .frame(width: 100, height: 100)
                .foregroundColor(.blue)
                .padding(.top, 30)
            
            Text("Usuario Ejemplo")
                .font(.title)
            
            Divider()
            
            VStack(alignment: .leading, spacing: 15) {
                InfoRow(icon: "envelope", text: "ceci@ejemplo.com")
                InfoRow(icon: "calendar", text: "Miembro desde: Enero 2025")
                InfoRow(icon: "chart.bar", text: "Nivel: Avanzado")
            }
            .padding()
            
            Spacer()
        }
        .navigationTitle("Perfil")
    }
}

struct InfoRow: View {
    let icon: String
    let text: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .frame(width: 30)
            Text(text)
            Spacer()
        }
    }
}

struct ConfiguracionView: View {
    @State private var notificaciones = true
    @AppStorage("modoOscuro") private var modoOscuro = false
    @Environment(\.colorScheme) private var colorScheme
    
    var body: some View {
        Form {
            Section(header: Text("Preferencias")) {
                Toggle("Notificaciones", isOn: $notificaciones)
                Toggle("Modo oscuro", isOn: $modoOscuro)
            }
            
            Section {
                Button("Cerrar sesión") {
                    // Acción de cerrar sesión
                }
                .foregroundColor(.red)
            }
            
            Section(header: Text("Acerca de")) {
                HStack {
                    Text("Versión")
                    Spacer()
                    Text("1.0.0")
                        .foregroundColor(.gray)
                }
            }
        }
        .navigationTitle("Configuración")
        .preferredColorScheme(modoOscuro ? .dark : .light) // Esto cambia el tema de toda la app
    }
}

struct Serenity_Previews: PreviewProvider {
    static var previews: some View {
        Group {
            NavigationStack {
                MeditacionesView()
            }
            NavigationStack {
                ProgresoView()
            }
            NavigationStack {
                PerfilView()
            }
            NavigationStack {
                ConfiguracionView()
            }
        }
    }
}
