//
//  SerenityTests.swift
//  SerenityTests
//
//  Created by Alumno on 03/04/25.
//

import Testing
@testable import Serenity

struct SerenityTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
